#ifndef __KERNEL6_H__
#define __KERNEL6_H__

int kernel6(int x);

#endif
