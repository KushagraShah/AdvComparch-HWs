#ifndef __KERNEL2_H__
#define __KERNEL2_H__

#define ARRAY_SIZE 1024

void kernel2( int array[ARRAY_SIZE] );

#endif