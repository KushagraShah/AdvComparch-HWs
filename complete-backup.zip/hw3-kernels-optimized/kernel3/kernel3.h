#ifndef __KERNEL3_H__
#define __KERNEL3_H__

#define ARRAY_SIZE 1024

void kernel3( float hist[ARRAY_SIZE], float weight[ARRAY_SIZE], int index[ARRAY_SIZE]);

#endif
