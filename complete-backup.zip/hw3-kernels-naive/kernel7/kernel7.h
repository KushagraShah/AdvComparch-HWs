#ifndef __KERNEL7_H__
#define __KERNEL7_H__

#define ARRAY_SIZE 1024

float kernel7(float a[ARRAY_SIZE], float b[ARRAY_SIZE]);

#endif
