#ifndef __KERNEL8_H__
#define __KERNEL8_H__

#define ARRAY_SIZE 1024

void kernel8(int array[ARRAY_SIZE], int multiplier, int offset);

#endif
