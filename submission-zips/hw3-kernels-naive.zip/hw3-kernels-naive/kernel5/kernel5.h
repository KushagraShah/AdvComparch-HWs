#ifndef __KERNEL5_H__
#define __KERNEL5_H__

#define ARRAY_SIZE 1024

float kernel5(float bound, float a[ARRAY_SIZE], float b[ARRAY_SIZE]);

#endif
