#ifndef __KERNEL4_H__
#define __KERNEL4_H__

#define ARRAY_SIZE 1024

void kernel4(int array[ARRAY_SIZE], int index[ARRAY_SIZE], int offset);

#endif
