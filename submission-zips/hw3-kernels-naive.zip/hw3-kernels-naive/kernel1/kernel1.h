#ifndef __KERNEL1_H__
#define __KERNEL1_H__

#define ARRAY_SIZE 1024

void kernel1( int array[ARRAY_SIZE] );

#endif
